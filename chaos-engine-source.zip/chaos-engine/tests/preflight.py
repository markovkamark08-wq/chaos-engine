import json
from pathlib import Path
root = Path(__file__).resolve().parents[1]
systems = json.loads((root / 'sheets' / 'systems.json').read_text(encoding='utf-8'))
content = json.loads((root / 'sheets' / 'content.json').read_text(encoding='utf-8'))
errors = []
ids = set()
for row in systems['systems']:
    if not row.get('id') or row['id'] in ids: errors.append(f"missing/duplicate system id: {row.get('id')}")
    ids.add(row.get('id'))
    for key in ('host', 'role', 'status', 'checks'):
        if key not in row: errors.append(f"{row.get('id')}: missing {key}")
content_ids = set()
for group in ('items','weapons','enemy_systems','movement_systems','world_systems'):
    for row in content.get(group, []):
        if not row.get('id'): errors.append(f'{group}: row missing id')
        elif row['id'] in content_ids: errors.append(f'{group}: duplicate id {row["id"]}')
        content_ids.add(row.get('id'))
        for key in ('source','effect','gameplay_status'):
            if key not in row: errors.append(f'{row.get("id")}: missing {key}')
if errors:
    print('PREFLIGHT: FAIL')
    print('\n'.join(errors))
    raise SystemExit(1)
print(f'PREFLIGHT: PASS — {len(systems["systems"])} systems, {len(content_ids)} content rows structurally complete.')
print('IMPLEMENTATION GAPS: companion gameplay adapters and in-game test remain unfinished.')
