using System;
using System.Collections.Generic;
using System.IO;
using BepInEx;
using UnityEngine;

namespace ChaosEngine
{
    [BepInPlugin("community.chaosengine.sixgame", "ULTRAKILL: CHAOS ENGINE", "0.0.1")]
    public sealed class ChaosEnginePlugin : BaseUnityPlugin
    {
        private readonly Dictionary<string, CompanionIndex> _companions = new Dictionary<string, CompanionIndex>();
        private int _surgeCount;
        private string _lastEvent = "Waiting for first test event";
        private bool _showOverlay = true;

        private sealed class CompanionIndex
        {
            public string DisplayName;
            public string EnvironmentKey;
            public string Folder;
            public int FileCount;
            public bool Found;
        }

        private void Awake()
        {
            AddCompanion("The Binding of Isaac: Rebirth", "CHAOS_ISAAC_DIR");
            AddCompanion("Totally Accurate Battle Simulator", "CHAOS_TABS_DIR");
            AddCompanion("Stick It to the Stickman", "CHAOS_STICKMAN_DIR");
            AddCompanion("Teardown", "CHAOS_TEARDOWN_DIR");
            AddCompanion("Geometry Dash", "CHAOS_GEOMETRYDASH_DIR");
            RefreshIndexes();
            Logger.LogInfo("CHAOS ENGINE scaffold loaded. Press Q to run the integration smoke-test event.");
        }

        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.Q))
            {
                _surgeCount++;
                RefreshIndexes();
                _lastEvent = "Chaos event #" + _surgeCount + " — companion scan refreshed";
                Logger.LogInfo(_lastEvent);
            }
            if (Input.GetKeyDown(KeyCode.F8)) _showOverlay = !_showOverlay;
        }

        private void AddCompanion(string name, string envKey)
        {
            string folder = Environment.GetEnvironmentVariable(envKey);
            _companions[envKey] = new CompanionIndex
            {
                DisplayName = name,
                EnvironmentKey = envKey,
                Folder = String.IsNullOrWhiteSpace(folder) ? "" : folder,
                Found = !String.IsNullOrWhiteSpace(folder) && Directory.Exists(folder),
                FileCount = 0
            };
        }

        private void RefreshIndexes()
        {
            foreach (CompanionIndex item in _companions.Values)
            {
                item.Found = !String.IsNullOrWhiteSpace(item.Folder) && Directory.Exists(item.Folder);
                item.FileCount = 0;
                if (!item.Found) continue;
                try
                {
                    // Index names only. Never copy game files into the mod or package.
                    foreach (string ignored in Directory.EnumerateFiles(item.Folder, "*", SearchOption.AllDirectories))
                    {
                        item.FileCount++;
                        if (item.FileCount >= 100000) break;
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogWarning("Could not fully index " + item.DisplayName + ": " + ex.GetType().Name);
                }
            }
        }

        private void OnGUI()
        {
            if (!_showOverlay) return;
            GUI.Box(new Rect(16, 16, 440, 225), "ULTRAKILL: CHAOS ENGINE — DEV BUILD");
            GUI.Label(new Rect(30, 44, 410, 24), "Q: run integration smoke test    F8: hide overlay");
            GUI.Label(new Rect(30, 68, 410, 24), _lastEvent);
            int y = 95;
            foreach (CompanionIndex item in _companions.Values)
            {
                string status = item.Found ? "folder found; indexed " + item.FileCount + " files" : "folder not mapped";
                GUI.Label(new Rect(30, y, 410, 22), item.DisplayName + ": " + status);
                y += 23;
            }
        }
    }
}
