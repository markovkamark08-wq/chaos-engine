# ULTRAKILL: CHAOS ENGINE

**Status: source scaffold / not yet a playable release.** This folder is the first implementation pass for a solo ULTRAKILL-hosted mashup. It is not a standalone game and does not ship any game-owned assets.

## Intended player experience
Enter a compact arena, trigger a chaos surge, and fight through a changing combat room. The integration layer discovers files in the player's own installs of all five companion games. Actual cross-game gameplay adapters are not complete yet; file discovery alone is not presented as full integration.

## Host and companions
- **Primary host:** ULTRAKILL (Unity; Melty-managed BepInEx 5 plugin route)
- **Required companions:** The Binding of Isaac: Rebirth, Totally Accurate Battle Simulator, Stick It to the Stickman, Teardown, Geometry Dash
- **Mode:** solo
- **Multiplayer:** none

The game folders must be passed by the eventual Melty recipe as environment variables. The plugin reads them in place and never copies game content into this project or its package.

## Current implementation
- BepInEx plugin scaffold with an in-game status overlay and a Q-key test event.
- Companion-folder presence checks and a local file index (names/extensions only; no assets copied).
- Data sheets describing the intended mechanics and explicit integration status.
- Preflight test validates sheet structure and references.

## Not yet done
This is not ready to upload as a release: no verified in-game build, no actual companion-specific content adapters, no Melty recipe validated by Melty, no gameplay screenshot, no passing `test_release`, and no license/remix decision. Do not publish this source scaffold as if it were the complete six-game mashup.

## Build requirements
Windows, the player's ULTRAKILL install, Melty-managed BepInEx 5, and a .NET SDK compatible with the game's Mono assemblies. Build using `build.ps1` after setting `ULTRAKILL_DIR` to the actual game folder. The script references the player's installed game assemblies; it does not bundle them.

## Distribution decisions still required
- License: awaiting creator choice.
- Remix permission: awaiting creator choice.
