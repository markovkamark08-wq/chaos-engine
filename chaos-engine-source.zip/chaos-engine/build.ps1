param(
  [Parameter(Mandatory=$true)][string]$UltrakillDir
)
$ErrorActionPreference = 'Stop'
if (!(Test-Path (Join-Path $UltrakillDir 'BepInEx\core\BepInEx.dll'))) {
  throw 'BepInEx 5 core was not found in this ULTRAKILL folder. Let Melty install its supported loader first.'
}
$env:ULTRAKILL_DIR = (Resolve-Path $UltrakillDir).Path
$env:BEPINEX_DIR = Join-Path $env:ULTRAKILL_DIR 'BepInEx\core'
$env:UNITY_MANAGED_DIR = Join-Path $env:ULTRAKILL_DIR 'ULTRAKILL_Data\Managed'
dotnet build (Join-Path $PSScriptRoot 'ChaosEngine.csproj') -c Release -p:ULTRAKILL_DIR="$env:ULTRAKILL_DIR"
if ($LASTEXITCODE -ne 0) { throw 'Build failed; see compiler output above.' }
Write-Host 'Source scaffold built. This is not yet a gameplay-complete release.'
